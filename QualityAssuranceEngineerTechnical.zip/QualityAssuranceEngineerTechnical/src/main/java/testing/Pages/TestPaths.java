package testing.Pages;
import org.openqa.selenium.By;
public class TestPaths {
    public static String url() {return "https://www.way2automation.com/angularjs-protractor/webtables/";}
    public static By edit(String Email) {return By.xpath("//div[contains(text(),'"+Email+"')]");}
    public static By AddUser() {return By.xpath("/html/body/table/thead/tr[2]/td/button");}

}
